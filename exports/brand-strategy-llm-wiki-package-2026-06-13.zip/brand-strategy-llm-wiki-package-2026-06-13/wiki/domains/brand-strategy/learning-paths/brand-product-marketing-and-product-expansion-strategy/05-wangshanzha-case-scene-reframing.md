---
title: 05｜望山楂案例：把产品改写成强场景解决方案
type: case
created: 2026-06-03
updated: 2026-06-05
domain: brand-strategy
tags: [brand-strategy, case-study, scene-marketing, slogan, xiaohongshu]
sources:
  - raw/transcripts/brand-product-marketing-and-product-expansion-strategy-2026-06-03.md
status: active
---

# 05｜望山楂案例：把产品改写成强场景解决方案

## 摘要

望山楂从"腻了撑了喝望山楂"改为"吃辣就喝望山楂"，是一个把模糊需求改写成强场景解决方案的经典案例。本章拆解这次改写的底层逻辑：找到原点人群、锁定高多巴胺场景、用魔性洗脑内容打穿心智，并通过场景裂变把"吃辣"从火锅延伸到烧烤、湘菜、川菜全品类。

## 核心问题

- 旧 slogan 为什么不起效？
- 怎样找到能打穿心智的核心场景？
- 小红书的内容策略如何围绕单一场景持续放大？

## 方法框架：旧版 vs 新版 slogan 对比

| 版本 | slogan | 问题 / 优势 |
| --- | --- | --- |
| 旧版 | 腻了撑了喝望山楂 | 腻了撑了的人不想再喝带气泡的饮料；需求不强，场景回避型 |
| 新版 | 吃辣就喝望山楂 | 吃辣是主动场景；辣是痛觉且会分泌多巴胺，情绪上头时消费冲动强 |

## 推导逻辑：原点人群 → 核心场景 → 内容扩散

望山楂做过明确的原点人群分析，目标用户是"高消费月底空的年轻人"，拆解出来的典型标签之一是：**下班去喝社交酒的年轻人**——这类人的典型场景是吃火锅，社交不是正式酒桌文化，是三五好友一起吐槽，氛围本身就容易上头。

场景锁定吃辣之后，进一步做了场景裂变：
- 火锅 → 烧烤 → 湘菜 / 川菜 → 江西菜 → 长沙酱板鸭
- 吃辣就一个关键词，但能覆盖所有辣系场景

小红书内容策略：魔性洗脑 + 话题挑战 + UGC 裂变
- 与龚琳娜（川渝人、能吃辣）合作短视频，用土嗨洗脑歌词反复植入"吃辣就喝望山楂"
- 发起"101个不能吃辣的人"挑战，能吃辣 vs 不能吃辣，借望山楂助阵
- 下面的粉丝把内容分发，形成大量同类内容，在小红书形成心智化传播

## 品牌延伸：谐音梗拓场景

在核心大单品场景打穿之后，望山楂利用"旺"字的中国许愿情节，拓展出系列场景 SKU：
- 望幸福 → 新婚场景
- 望桃花 → 下午茶、姻缘场景
- 望美好 → 社会性话题（女性幸福自定义）
- 望勇敢 → 职场场景（跟老板"干仗"）
- 望成功 → 考试季、考公上岸季

每个词都可以生成大量内容：一瓶望成功 + 三年考公落榜 + 今年一定上岸，这就是完整的内容脚本。

## 核心原则

一旦找到高多巴胺场景（吃辣/火锅/喝酒），消费者上头时几乎不会计算消费量和价格，这是在场景分析中最值得找的"情绪加速器"。找到之后，用单一场景关键词反复洗脑，不分散，不换话题，持续打穿。

## 判断标准

- 你的场景是否主动型（用户想做某件事）而非回避型（出问题才想到你）？
- 你的场景是否对应高情绪/高多巴胺状态，让消费冲动更自然？
- 你的内容是否围绕同一场景持续裂变，而不是每条内容换一个卖点？

## 常见误区

- 旧版"腻了撑了"：场景是负面的、被动的，用户倾向回避而非寻找。
- 把场景定义得太宽（"餐饮场景"），失去强度和记忆锚点。
- 大量内容各说各话，没有一个可以持续洗脑的单一关键词。

## 可用于 Agent 的提示词

> 给定一个产品和现有的 slogan，请判断它是主动场景还是被动/回避场景，如果是被动场景，请重新找到一个高多巴胺的主动场景，并输出：1）新场景关键词；2）小红书洗脑内容方向（三条）；3）谐音梗或情绪延伸系列 SKU 命名建议（3-5 个）。

## 相关页面

- [[domains/brand-strategy/learning-paths/brand-product-marketing-and-product-expansion-strategy/03-scene-marketing-vs-situation-marketing|03｜场景营销与情景营销]]
- [[domains/brand-strategy/learning-paths/brand-product-marketing-and-product-expansion-strategy/04-channel-specific-expression-rules|04｜不同渠道的表达规则]]
- [[domains/brand-strategy/learning-paths/brand-product-marketing-and-product-expansion-strategy/06-product-line-expansion-logic|06｜拓品的逻辑与边界]]

## 来源

- `raw/transcripts/brand-product-marketing-and-product-expansion-strategy-2026-06-03.md`
