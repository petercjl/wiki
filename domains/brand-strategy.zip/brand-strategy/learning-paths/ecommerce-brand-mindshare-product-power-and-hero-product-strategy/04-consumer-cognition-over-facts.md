---
title: 04｜消费者认知为什么比事实更重要
type: concept
created: 2026-06-03
updated: 2026-06-03
domain: brand-strategy
tags: [brand-strategy, business-analysis, workflow]
sources:
  - raw/transcripts/ecommerce-brand-mindshare-product-power-and-hero-product-strategy-2026-06-03.md
status: active
---

# 04｜消费者认知为什么比事实更重要

## 核心判断

赛道判断不能只看事实，还要看消费者是否已经具备认知入口。

## 方法含义

本节用于把课程中的口头经验重构成稳定的方法框架。重点不是复述课堂顺序，而是把判断标准、行动顺序、案例证据与适用边界整理成可复用知识。

## 操作要点

1. 先明确这一节要解决的经营问题。
2. 再区分哪些内容是可迁移原则，哪些只是案例情境。
3. 用案例中的数字或显性证据验证结论，而不是只保留抽象口号。

## 可用于 Agent 的提示词

> 请基于本节方法，分析当前品牌/产品/视觉材料是否存在同类问题，并给出对应的调整建议。

